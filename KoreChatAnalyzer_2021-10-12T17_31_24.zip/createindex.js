db.transitionrecords.createIndexes([{"metaInfo.identity":1,"timestamp":1}],{"name":"metaInfo.identity_1_timestamp_1","background":true})

db.transitionrecords.createIndexes([{"timestamp":1, "metaInfo.channel": 1}],{"name":"timestamp_1_metaInfo.channel_1","background":true})