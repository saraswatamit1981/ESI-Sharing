import copy, json
import pandas as pd
from common import style, time_usage, log

def records_to_dict(record_list):
    rec = {}
    for record in record_list:
        uId = record.get('userId', None)
        callId = record.get('metaInfo', {}).get('identity',uId)
        if uId:
            if uId not in rec:
                rec[uId] = []
            rec[uId].append(record)
        else:
            pass
    if len(rec) > 0:
        for user in rec:
            rec[user] = sorted(rec[user], key=lambda k: k['timestamp'])
    return rec

def chat_to_identity_map(record_list):
    rec = {}
    for record in record_list:
        uId = record.get('userId', None)
        identity = record.get('metaInfo', {}).get('identity',uId)
        if identity:
            if identity not in rec:
                rec[identity] = []
            rec[identity].append(record)
        else:
            pass
    if len(rec) > 0:
        for identity in rec:
            rec[identity] = sorted(rec[identity], key=lambda k: k['timestamp'])
    return rec

@time_usage
def filterCallsInDateTimeRange(user_data, user_first_call, from_date_time, end_date_time, upper_boundary, lower_boundary, boundary_check=True):
    res = {}
    skipped_users_list = []
    for user in user_data:
        if user in user_first_call:
            if boundary_check:
                # call must be started after upper_boundary and no continuation after lower_boundary
                if user_first_call[user] >= upper_boundary and user_data[user][-1]["timestamp"] <= lower_boundary and user_data[user][-1]["timestamp"] >= from_date_time:
                    res[user] = user_data[user]
                else:
                    skipped_users_list.append(user)
            else:
                res[user] = user_data[user]
        else:
            skipped_users_list.append(user)
    return res

def build_dialog_from_call(call_flow):
    res = []
    for each in call_flow:
        if "nodeId" in each:
            if len(res) == 0 or res[-1] != each["nodeId"]:
                res.append(each["nodeId"])
    return res

@time_usage
def build_dialog_flow_for_calls(users_calls_list):
    res = {}
    for user in users_calls_list:
        call_flow = build_dialog_from_call(users_calls_list[user])
        if len(call_flow) > 0:
            res[user] = {}
            res[user]["userId"] = users_calls_list[user][0].get("userId", user)
            res[user]["identity"] = users_calls_list[user][0].get('metaInfo', {}).get('identity',user)
            res[user]["call_data"] = copy.deepcopy(users_calls_list[user])
            res[user]["call_flow"] = call_flow
            res[user]["nodes"] = list(set(res[user]["call_flow"]))
            res[user]["labels_qualification"] = []
            res[user]["labels_fulfillment"] = []
            res[user]["labels_qualification_failures"] = {}
            res[user]["labels_fulfillment_failures"] = {}
            res[user]["rules_qualification"] = []
            res[user]["rules_fulfillment"] = []
            res[user]["rules_qualification_failures"] = {}
            res[user]["rules_fulfillment_failures"] = {}
    return res

def node_match(node, dialog_flow, dlg_node_idx):
    try:
        pos = dialog_flow.index(node, dlg_node_idx)
    except:
        pos = -1
    return pos

def order_match_nodes(rule_meta_name, rule_meta_all_nodes, user_nodes, data_failure, back_track=True):
    status = False
    stk = []
    hst = []
    node_idx = 0
    dlg_node_idx = 0
    len_nodes = len(rule_meta_all_nodes)
    len_dlg = len(user_nodes)
    loop_count = 0
    while True:
        loop_count += 1
        if node_idx >= len_nodes:
            status = True
            break
        if dlg_node_idx >= len_dlg:
            break
        if loop_count >= 100:
            # should not occour
            log.exception("Dialog loop")
            break
        pos = node_match(rule_meta_all_nodes[node_idx], user_nodes, dlg_node_idx)
        dlg_node_idx = pos
        if pos >= 0:
            if back_track and (node_idx, dlg_node_idx) not in hst:
                stk.append((node_idx, dlg_node_idx))
                hst.append((node_idx, dlg_node_idx))
            node_idx += 1
            if rule_meta_name in data_failure:
                del(data_failure[rule_meta_name])
        else:
            if rule_meta_name not in data_failure:
                data_failure[rule_meta_name] = rule_meta_all_nodes[node_idx]
            if len(stk) > 0:
                node_idx, dlg_node_idx = stk.pop()
            else:
                break
    if status and rule_meta_name in data_failure:
        del(data_failure[rule_meta_name])
    return status

def validate_all_of_nodes(rule_meta_name, rule_meta_all_nodes, user_nodes, data_failure):
    status = False
    if rule_meta_all_nodes.issubset(user_nodes):
        status = True
    else:
        data_failure[rule_meta_name] = list(rule_meta_all_nodes - user_nodes.intersection(rule_meta_all_nodes))
    return status

def validate_none_of_nodes(rule_meta_name, rule_meta_none_nodes, user_nodes, data_failure):
    status = False
    none_nodes = user_nodes.intersection(rule_meta_none_nodes)
    if len(none_nodes) == 0:
        status = True
    else:
        data_failure[rule_meta_name] = list(none_nodes)
    return status

@time_usage
def calls_label_match(users_call_map, rules_meta={}):
    labels = rules_meta.get("labels", {})
    if len(labels) > 0:
        for user in users_call_map:
            user_nodes = set(users_call_map[user]["nodes"])
            for label in labels:
                label_qualification_all_of_nodes = set(labels[label].get("qualification", {}).get("all-of-nodes", []))
                label_qualification_none_of_nodes = set(labels[label].get("qualification", {}).get("none-of-nodes", []))
                label_fulfillment_all_of_nodes = set(labels[label].get("fulfillment", {}).get("all-of-nodes", []))
                label_fulfillment_none_of_nodes = set(labels[label].get("fulfillment", {}).get("none-of-nodes", []))
                if validate_all_of_nodes(label, label_qualification_all_of_nodes, user_nodes, users_call_map[user]["labels_qualification_failures"]) \
                    and order_match_nodes(label, labels[label].get("qualification", {}).get("all-of-nodes", []), users_call_map[user]["call_flow"], \
                        users_call_map[user]["labels_qualification_failures"]):
                    if validate_none_of_nodes(label, label_qualification_none_of_nodes, user_nodes, users_call_map[user]["labels_qualification_failures"]):
                        users_call_map[user]["labels_qualification"].append(label)
                        if validate_all_of_nodes(label, label_fulfillment_all_of_nodes, user_nodes, users_call_map[user]["labels_fulfillment_failures"]) \
                            and order_match_nodes(label, labels[label].get("fulfillment", {}).get("all-of-nodes", []), users_call_map[user]["call_flow"], \
                                users_call_map[user]["labels_fulfillment_failures"]):
                            if validate_none_of_nodes(label, label_fulfillment_none_of_nodes, user_nodes, users_call_map[user]["labels_fulfillment_failures"]):
                                users_call_map[user]["labels_fulfillment"].append(label)
    return users_call_map

def validate_all_of_labels(rule_meta_name, rule_meta_all_of_labels, user_labels, data_failure):
    status = False
    if rule_meta_all_of_labels.issubset(user_labels):
        status = True
    else:
        data_failure[rule_meta_name] = list(rule_meta_all_of_labels - user_labels.intersection(rule_meta_all_of_labels))
    return status

def validate_none_of_labels(rule_meta_name, rule_meta_none_of_labels, user_labels, data_failure):
    status = False
    none_labels = user_labels.intersection(rule_meta_none_of_labels)
    if len(none_labels) == 0:
        status = True
    else:
        data_failure[rule_meta_name] = list(none_labels)
    return status

@time_usage
def calls_rule_match(users_call_map, rules_meta={}):
    rules = rules_meta.get("rules", {})
    if len(rules) > 0:
        for user in users_call_map:
            user_labels = set(users_call_map[user].get("labels_fulfillment", []))
            if len(user_labels) == 0:
                continue
            for rule in rules:
                rule_qualification_all_of_labels = set(rules[rule].get("qualification", {}).get("all-of-labels", []))
                rule_qualification_none_of_labels = set(rules[rule].get("qualification", {}).get("none-of-labels", []))
                rule_fulfillment_all_of_labels = set(rules[rule].get("fulfillment", {}).get("all-of-labels", []))
                rule_fulfillment_none_of_labels = set(rules[rule].get("fulfillment", {}).get("none-of-labels", []))
                if validate_all_of_labels(rule, rule_qualification_all_of_labels, user_labels, users_call_map[user]["rules_qualification_failures"]):
                    if validate_none_of_labels(rule, rule_qualification_none_of_labels, user_labels, users_call_map[user]["rules_qualification_failures"]):
                        users_call_map[user]["rules_qualification"].append(rule)
                        if validate_all_of_labels(rule, rule_fulfillment_all_of_labels, user_labels, users_call_map[user]["rules_fulfillment_failures"]):
                            if validate_none_of_labels(rule, rule_fulfillment_none_of_labels, user_labels, users_call_map[user]["rules_fulfillment_failures"]):
                                users_call_map[user]["rules_fulfillment"].append(rule)
    return users_call_map

@time_usage
def generate_conversation_meta(users_call_map):
    data = []
    for user in users_call_map:
        data.append([users_call_map[user]["userId"], users_call_map[user]["identity"], ' -> '.join(users_call_map[user]["call_flow"]), ', '.join(users_call_map[user]["labels_fulfillment"])])
    df = pd.DataFrame(data, columns=["userId", "Id", "Dialog Flow", "Fulfilled Labels"])
    return df

@time_usage
def generate_rules_summary(users_call_map, rules):
    data = []
    calls_inspected_count = len(users_call_map)
    for rule in rules:
        calls_qualified_count = 0
        calls_fulfilled_count = 0
        calls_unfulfilled_count = 0
        unfulfilled_calls_details = []
        for user in users_call_map:
            if rule in users_call_map[user]["rules_qualification"]:
                calls_qualified_count += 1
            if rule in users_call_map[user]["rules_fulfillment"]:
                calls_fulfilled_count += 1
            if rule in users_call_map[user]["rules_fulfillment_failures"]:
                calls_unfulfilled_count += 1
                unfulfilled_calls_details.append(["", "", "", "", "", user, "", ""])
                for label in users_call_map[user]["rules_fulfillment_failures"][rule]:
                    if label in users_call_map[user]["labels_fulfillment_failures"]:
                        unfulfilled_calls_details.append(["", "", "", "", "", "", label, ', '.join(users_call_map[user]["labels_fulfillment_failures"][label])])
                    elif label in users_call_map[user]["labels_qualification_failures"]:
                        unfulfilled_calls_details.append(["", "", "", "", "", "", label, ', '.join(users_call_map[user]["labels_qualification_failures"][label])])
                    else:
                        unfulfilled_calls_details.append(["", "", "", "", "", "", label, ""])
        data.append([rule, calls_inspected_count, calls_qualified_count, calls_fulfilled_count, calls_unfulfilled_count, "", "", ""])
        if len(unfulfilled_calls_details) > 0:
            data.extend(unfulfilled_calls_details)
    df = pd.DataFrame(data, columns=["Rule", "Calls Inspected", "Calls Qualified", "Calls Fulfilled", "Calls Unfulfilled", "Unfulfilled Call Details", "Unfulfilled Labels", ""])
    return df

@time_usage
def generate_overall_summary(users_call_map, rules):
    data = []
    calls_inspected_count = len(users_call_map)
    overall_rule_map = {}
    overall_user = set()
    unqualified_user = set()
    overall_rule_qualified = set()
    overall_rule_fulfilled = set()
    overall_rule_unfulfilled = set()
    for rule in rules:
        overall_rule_map[rule] = {}
        overall_rule_map[rule]["qualified_ids"] = set()
        overall_rule_map[rule]["fulfilled_ids"] = set()
        overall_rule_map[rule]["unfulfilled_ids"] = set()
        calls_qualified_count = 0
        calls_fulfilled_count = 0
        calls_unfulfilled_count = 0
        for user in users_call_map:
            overall_user.add(user)
            if len(users_call_map[user]["rules_qualification"]) > 0:
                overall_rule_map[rule]["qualified_ids"].add(user)
            else:
                unqualified_user.add(user)
            if len(users_call_map[user]["rules_fulfillment"]) == 0:
                overall_rule_map[rule]["unfulfilled_ids"].add(user)
            else:
                overall_rule_map[rule]["fulfilled_ids"].add(user)
            if rule in users_call_map[user]["rules_qualification"]:
                calls_qualified_count += 1
            if rule in users_call_map[user]["rules_fulfillment"]:
                calls_fulfilled_count += 1
            if rule in users_call_map[user]["rules_fulfillment_failures"]:
                calls_unfulfilled_count += 1
        data.append([rule, calls_inspected_count, calls_qualified_count, calls_fulfilled_count, calls_unfulfilled_count])
    data.append(["", "", "", "", ""])
    data.append(["", "", "", "", ""])
    data.append(["", "", "", "", ""])
    overall_rule_unfulfilled = overall_user - unqualified_user
    for rule in overall_rule_map:
        overall_rule_qualified = overall_rule_qualified.union(overall_rule_map[rule]["qualified_ids"])
        overall_rule_fulfilled = overall_rule_qualified.union(overall_rule_map[rule]["fulfilled_ids"])
        overall_rule_unfulfilled = overall_rule_unfulfilled.intersection(overall_rule_map[rule]["unfulfilled_ids"])
    data.append(["Total", calls_inspected_count, len(overall_rule_qualified), len(overall_rule_fulfilled), len(overall_rule_unfulfilled)])
    df = pd.DataFrame(data, columns=["Rule", "Calls Inspected", "Calls Qualified", "Calls Fulfilled", "Calls Unfulfilled"])
    return df

@time_usage
def generate_report(users_call_map, rules_meta, file_name):
    log.debug("Users Call Map - " + json.dumps(users_call_map, indent=4))
    conversation_meta = generate_conversation_meta(users_call_map)
    rules_summary = generate_rules_summary(users_call_map, rules_meta.get("rules", {}))
    overall_summary = generate_overall_summary(users_call_map, rules_meta.get("rules", {}))
    with pd.ExcelWriter(file_name) as writer:
        conversation_meta.to_excel(writer, sheet_name="Conversation Meta", index=False)
        rules_summary.to_excel(writer, sheet_name="Rules Summary", index=False)
        overall_summary.to_excel(writer, sheet_name="Overall Summary", index=False)
    return