# KORE Chat Analyzer

> Prerequisite : run the mongo index queries present in createindex.js in the mongodb

> Requirements : Python 3.6, virtualenv

## Installation Steps

* Download the repo and go to KoreChatAnalyzer directory or extract KoreChatAnalyzer_\<date\>.zip provided into KoreChatAnalyzer directory.
* `cd KoreChatAnalyzer`
* create virtual environment using python 3.6: \
&ensp; `virtualenv venv --python=python3.6`
* activate venv using: \
&ensp; `source venv/bin/activate`
* install requirements.txt: \
&ensp; `pip install -r requirements.txt`
* configure the script using `config.json` for regular parameters. Other required parameters can be passed as command line parameters also.
* modify `rules.json` following the given format.
* run the script `main.py` using the following command: \
&ensp; `python main.py start_date=YYYY-MM-ddTHH:mm:ss+00:00 end_date=YYYY-MM-ddTHH:mm:ss+00:00`
* the result .xlsx file will be generated in data folder configured via `DATA_FOLDER` given in config.