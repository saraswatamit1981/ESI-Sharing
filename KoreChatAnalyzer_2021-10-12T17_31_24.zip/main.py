import json
from config import configuration, DURATION, END_TIME_CUTOFF, DATA_FOLDER, CHAT_BOUNDARY_CHECK
import dataLoader, dataProcessor
from common import log, log_start_program, log_end_program, getDateRange, reduceDateTime, generate_op_file_name, time_usage

@time_usage
def execute_script():
    # rec = dataLoader.getSampleCallRecord()
    # print(rec)
    from_date_time, end_date_time = getDateRange()
    log.info("Current run from " + str(from_date_time) + " to " + str(end_date_time))
    from_date_time_boundary = reduceDateTime(from_date_time, DURATION)
    end_date_time_boundary = reduceDateTime(end_date_time, END_TIME_CUTOFF)
    rec = dataLoader.getCurrentRunCallDetails(from_date_time_boundary, end_date_time)
    # print(rec)
    log.debug("Call Data = ")
    #log.debug(rec)
    #recDict = dataProcessor.records_to_dict(rec)
    identity_call_map = dataProcessor.chat_to_identity_map(rec)
    log.debug("Unifiltered Calls - " + str(len(identity_call_map)))
    log.debug("Call Data per user = ")
    #log.debug(recDict)
    #user_ids = [x for x in recDict]
    #userid_identities_map = {x: recDict[x][0].get("metaInfo", {}).get("identity", x) for x in recDict}
    identities = [x for x in identity_call_map]
    #user_ids = [(x,recDict[x][0]["streamId"]) for x in recDict if "streamId" in recDict[x][0]]
    #user_first_call = dataLoader.getFirstCallDateTime(user_ids, from_date_time_boundary)
    #user_first_call = dataLoader.getFirstCallDateTimeFromIdentity(userid_identities_map, from_date_time_boundary)
    identity_first_call = dataLoader.getFirstCallDateTimeFromIdentity(identities, from_date_time_boundary)
    filtered_calls = dataProcessor.filterCallsInDateTimeRange(identity_call_map, identity_first_call, from_date_time, end_date_time, from_date_time_boundary, \
        end_date_time_boundary, CHAT_BOUNDARY_CHECK)
    #print(filtered_calls)
    #log.debug(filtered_calls)
    filtered_calls = dataProcessor.build_dialog_flow_for_calls(filtered_calls)
    log.info("Total calls within time boundary are - " + str(len(filtered_calls)))
    rules = dataLoader.getRules()
    labeled_calls = dataProcessor.calls_label_match(filtered_calls, rules)
    ruled_calls = dataProcessor.calls_rule_match(labeled_calls, rules)
    #print(ruled_calls)
    #log.debug(ruled_calls)
    op_file_name = generate_op_file_name(from_date_time, end_date_time)
    dataProcessor.generate_report(ruled_calls, rules, op_file_name)

if __name__ == '__main__':
    log_start_program()
    log.debug(json.dumps(configuration, indent=4))
    execute_script()
    log_end_program()