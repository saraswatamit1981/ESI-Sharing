import datetime, json, time
from config import MONGO_URL, TRANSITION_RECORDS_DB, TRANSITION_RECORDS_COLLECTION, MONGO_TIMEOUT, RULES_FILE_PATH, GET_FIRST_CHAT, CHANNEL
from common import log, log_start_program, log_end_program, loadJson, time_usage

from pymongo import MongoClient, ASCENDING, DESCENDING


try:
    client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=MONGO_TIMEOUT)
    client.server_info()
except Exception as err:
    log_start_program()
    print("Could not connect to mongo with error - "+str(err))
    log.exception("Could not connect to mongo with error - "+str(err))
    log_end_program()
    exit(0)

# client = MongoClient(MONGO_URL, connect=False)
transition_records_db = client[TRANSITION_RECORDS_DB]
transition_records_collection = transition_records_db[TRANSITION_RECORDS_COLLECTION]

def getSampleCallRecord():
    rec = None
    try:
        rec = transition_records_collection.find_one()
        log.debug(str(rec))
    except Exception as err:
        log.exception("FAILED QUERY - "+str(err))
    return rec

@time_usage
def getCurrentRunCallDetails(from_date_time=None, end_date_time=None):
    rec = []
    if not from_date_time or not end_date_time or from_date_time == end_date_time:
        log.exception("No Call records are extracted from " + str(from_date_time) + " to " + str(end_date_time))
        return rec
    try:
        log.info("Querying to fetch call data from " + str(from_date_time) + " to " + str(end_date_time))
        from_date_time = datetime.datetime.strptime(from_date_time, "%Y-%m-%dT%H:%M:%S.%f%z")
        end_date_time = datetime.datetime.strptime(end_date_time, "%Y-%m-%dT%H:%M:%S.%f%z")
        query = {"timestamp":{"$gte": from_date_time, "$lte": end_date_time}}
        if CHANNEL and CHANNEL != "*":
            query["metaInfo.channel"] = CHANNEL
        log.debug("Query - " + str(query))
        query_start = time.time()
        query_res = transition_records_collection.find(query, {"userId": 1, "timestamp": 1, "nodeId": 1, "debugTitle": 1, "metaInfo.identity": 1, "streamId": 1})
        log.info("Number of records - " + str(query_res.count()))
        query_end = time.time()
        log.info("Time taken for query - " + str(query_end - query_start) + " sec")
        for each in query_res:
            each["timestamp"] = each["timestamp"].replace(tzinfo=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
            if "nodeId" in each and "debugTitle" in each:
                each["nodeId"] = each["debugTitle"]
                # each["createdOn"] = each["createdOn"].replace(tzinfo=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
                rec.append(each)
    except Exception as err:
        log.exception("Query failed to fetch call data from " + str(from_date_time) + " to " + str(end_date_time) + " - " + str(err))
    return rec

@time_usage
def getFirstCallDateTime(user_ids, from_date_time):
    user_date_time = {}
    log.info("Querying for users first chat for " + str(len(user_ids)))
    c = 0
    for user in user_ids:
        c += 1
        log.debug("Querying for " + str(c) +" user - " + str(user))
        query = {"userId": user}
        if CHANNEL and CHANNEL != "*":
            query["metaInfo.channel"] = CHANNEL
        log.debug("Query - " + str(query))
        query_start = time.time()
        try:
            if GET_FIRST_CHAT:
                query_res = transition_records_collection.find_one(query, {"userId": 1, "timestamp": 1}) #, sort = [("timestamp", ASCENDING)])
                user_date_time[query_res["userId"]] = query_res["timestamp"].replace(tzinfo=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
            else:
                user_date_time[user] = from_date_time
        except Exception as err:
            log.exception("Query failed to get first call timestamp details for user - " + str(user) + " - " + str(err))
        query_end = time.time()
        log.debug("Time taken - " + str(query_end - query_start) + " sec")
    log.debug("Users First Call - " + json.dumps(user_date_time, indent=4))
    return user_date_time

@time_usage
def getFirstCallDateTimeFromIdentity(identities, from_date_time):
    identity_date_time = {}
    log.info("Querying for users first chat for " + str(len(identities)))
    c = 0
    for identity in identities:
        c += 1
        log.debug("Querying for " + str(c) +" identity - " + str(identity))
        query = {"metaInfo.identity": identity}
        if CHANNEL and CHANNEL != "*":
            query["metaInfo.channel"] = CHANNEL
        log.debug("Query - " + str(query))
        query_start = time.time()
        try:
            if GET_FIRST_CHAT:
                query_res = transition_records_collection.find_one(query, {"userId": 1, "timestamp": 1, "metaInfo.identity": 1}) #, sort = [("timestamp", ASCENDING)])
                identity_date_time[identity] = query_res["timestamp"].replace(tzinfo=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
            else:
                identity_date_time[identity] = from_date_time
        except Exception as err:
            log.exception("Query failed to get first call timestamp details for identity - " + str(identity) + " - " + str(err))
        query_end = time.time()
        log.debug("Time taken - " + str(query_end - query_start) + " sec")
    log.debug("Users First Call - " + json.dumps(identity_date_time, indent=4))
    return identity_date_time


def getRules():
    rules = loadJson(RULES_FILE_PATH)
    log.debug("Rules - " + json.dumps(rules, indent=4))
    return rules