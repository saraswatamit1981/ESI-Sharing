import sys, os, json, datetime, time
import logging as log
from logging.handlers import TimedRotatingFileHandler
from termcolor import colored
from config import CONVERSATION_START_TIME, CONVERSATION_END_TIME, DURATION
from config import LOG_FOLDER, LOG_NAME, LOG_DEBUG_LEVEL, DATA_FOLDER


def valid_path(path):
	if not os.path.exists(path):
		os.makedirs(path)
	if not path[-1] == '/':
		path += '/'
	return path


LOGFILE = valid_path(LOG_FOLDER)+ LOG_NAME + ".log"
log.Formatter.converter = time.gmtime
log_rotate_handler = TimedRotatingFileHandler(LOGFILE, when='midnight', backupCount=1000)
log.basicConfig(format= '%(asctime)s.%(msecs)03dZ - %(process)d - %(levelname)s - %(message)s ', datefmt='%m-%d-%YT%H:%M:%S' , level=log.DEBUG if LOG_DEBUG_LEVEL else log.INFO, handlers=[log_rotate_handler])


def loadJson(filePath, errLogMsg="", silent=False):
	data = {}
	try:
		with open(filePath) as fp:
			data = json.load(fp)
	except:
		errLogMsg = "Json : Could not load {filePath}. {errLogMsg}".format(filePath=filePath, errLogMsg=errLogMsg)
		if silent:
			log.debug(errLogMsg)
		else:
			log.exception(errLogMsg)
	return data

def log_start_program():
    print(50*"<",50*">")
    print("Starting the program")
    print(50*"<",50*">")
    log.info(50*"<"+50*">")
    log.info("Starting the program")
    log.info(50*"<"+50*">")

def log_end_program():
    print(50*"<",50*">")
    print("Ending the program")
    print(50*"<",50*">")
    log.info(50*"<"+50*">")
    log.info("Ending the program")
    log.info(50*"<"+50*">")

class style:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'
	
def time_usage(func):
	def wrapper(*args, **kwargs):
		beg_ts = time.time()
		retval = func(*args, **kwargs)
		end_ts = time.time()
		diff = end_ts - beg_ts
		Tcolor = "green"
		if diff > 1.0 and diff < 2.0:
			Tcolor = "yellow"
		elif diff >= 2.0 :
			Tcolor = "red"
		log.info( colored(func.__name__, Tcolor) + " elapsed time: " + str(diff) + " sec")
		return retval
	return wrapper

string_date_formats = [
	"%Y-%m-%dT%H:%M:%S %Z %z",
	"%Y-%m-%d %H:%M:%S %Z %z",
	"%Y-%m-%dT%H:%M:%S %z",
	"%Y-%m-%d %H:%M:%S %z",
	"%Y-%m-%dT%H:%M:%S",
	"%Y-%m-%d %H:%M:%S",
	"%Y-%m-%dT%H:%M %Z %z",
	"%Y-%m-%d %H:%M %Z %z",
	"%Y-%m-%dT%H:%M %z",
	"%Y-%m-%d %H:%M %z",
	"%Y-%m-%dT%H:%M",
	"%Y-%m-%d %H:%M",
	"%Y-%m-%d %Z %z",
	"%Y-%m-%d %z",
	"%Y-%m-%d"
]

def getDateTime(datetime_str):
	date_time = None
	for date_time_format in string_date_formats:
		try:
			date_time = datetime.datetime.strptime(datetime_str, date_time_format)
			if not date_time.tzinfo:
				date_time = date_time.replace(microsecond=0, tzinfo=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
			else:
				date_time = date_time.replace(microsecond=0).astimezone(tz=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
			break
		except Exception as err:
			#log.exception(err)
			pass
	if not date_time:
		log.exception("Could not format date - " + datetime_str)
	else:
		log.debug("Converted date time from " + datetime_str + " to " + date_time)
	return date_time

def getStartDateTime():
	from_date = None
	if CONVERSATION_START_TIME:
		from_date = getDateTime(CONVERSATION_START_TIME)
	if not from_date:
		from_date = (datetime.datetime.utcnow().replace(minute=0, second=0, microsecond=0) - datetime.timedelta(minutes=DURATION)).replace(tzinfo=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
	return from_date

def getEndDateTime():
	end_date = None
	if CONVERSATION_END_TIME:
		end_date = getDateTime(CONVERSATION_END_TIME)
	if not end_date:
		end_date = datetime.datetime.utcnow().replace(minute=0, second=0, microsecond=0, tzinfo=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f%z")
	return end_date

def getDateRange():
	from_date = getStartDateTime()
	end_date = getEndDateTime()
	if not from_date or not end_date:
		return None, None
	if from_date > end_date:
		from_date, end_date = end_date, from_date
	return from_date, end_date

def reduceDateTime(date_time_str, duration_minutes=DURATION):
	date_time = datetime.datetime.strptime(date_time_str, "%Y-%m-%dT%H:%M:%S.%f%z") - datetime.timedelta(minutes=duration_minutes)
	date_time_str = date_time.strftime("%Y-%m-%dT%H:%M:%S.%f%z")
	return date_time_str

def generate_op_file_name(from_date_time, end_date_time):
	file_name = os.path.join(DATA_FOLDER, from_date_time[:19]+"-"+end_date_time[:19]+".xlsx")
	return file_name