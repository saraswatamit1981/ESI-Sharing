# from common import commandlineParams, valid_path, loadJson
import sys, os, json
def loadJson(filePath, errLogMsg="", silent=False):
	data = {}
	try:
		with open(filePath) as fp:
			data = json.load(fp)
	except:
		errLogMsg = "Json : Could not load {filePath}. {errLogMsg}".format(filePath=filePath, errLogMsg=errLogMsg)
		if silent:
			log.debug(errLogMsg)
		else:
			log.exception(errLogMsg)
	return data

def commandlineParams(param_key, default=None, required=True):
	"""get commandline parameters, if not required default will be read"""
	param_key = param_key.strip()
	if not param_key[-1] == "=":
		param_key += "="
	if any(param_key in arg for arg in sys.argv):
		for arg in sys.argv:
			if param_key in arg:
				param_value = arg[len(param_key):]
				return param_value
	elif not required:
		return default
	else:
		log_start_program()
		print("please provide param : " + str(param_key))
		log.exception("please provide param : " + str(param_key))
		log_end_program()
		exit(0)

def valid_path(path):
	if not os.path.exists(path):
		os.makedirs(path)
	if not path[-1] == '/':
		path += '/'
	return path

jsonConfigFile = commandlineParams(param_key="config", default=None, required=False)
configuration = {}
if not jsonConfigFile:
    # read from command line params
    configuration["MONGO_URL"] = commandlineParams(param_key="mongo", default="mongodb://localhost:27017/?authSource=admin", required=True)
    configuration["MONGO_TIME_OUT"] = commandlineParams(param_key="mongo_time_out", default=30000, required=False)
    configuration["LOG_FOLDER"] = commandlineParams(param_key="log_folder", default="log/", required=False)
    configuration["LOG_NAME"] = commandlineParams(param_key="log_name", default="analyzer", required=False)
    configuration["LOG_DEBUG"] = commandlineParams(param_key="log_debug", default="true", required=False)
    configuration["DATA_FOLDER"] = commandlineParams(param_key="data_folder", default="data/", required=False)
    configuration["TRANSITION_RECORDS_DB"] = commandlineParams(param_key="transition_records_db", default="koredbt001", required=False)
    configuration["TRANSITION_RECORDS_COLLECTION"] = commandlineParams(param_key="transition_records_collection", default="transitionrecords", required=False)
    configuration["RULES_FILE_PATH"] = commandlineParams(param_key="rules_file_path", default="rules.json", required=False)
    configuration["START_TIME"] = commandlineParams(param_key="start_time", default=None, required=False)
    configuration["END_TIME"] = commandlineParams(param_key="end_time", default=None, required=False)
    configuration["DURATION"] = commandlineParams(param_key="duration", default=None, required=False)
    configuration["END_TIME_CUTOFF"] = commandlineParams(param_key="end_time_cutoff", default=None, required=False)
    configuration["CHANNEL"] = commandlineParams(param_key="channel", default="*", required=False)
    configuration["GET_FIRST_CHAT"] = commandlineParams(param_key="get_first_chat", default="true", required=False)
    configuration["CHAT_BOUNDARY_CHECK"] = commandlineParams(param_key="chat_boundary_check", default="true", required=False)
else:
    configuration = loadJson(jsonConfigFile)

if jsonConfigFile:
    #overwrite with cmd line parameters
    configKeysMap = {
        "MONGO_URL": "mongo",
        "MONGO_TIME_OUT": "mongo_time_out",
        "LOG_FOLDER": "log_folder",
        "LOG_NAME": "log_name",
        "LOG_DEBUG": "log_debug",
        "DATA_FOLDER": "data_folder",
        "TRANSITION_RECORDS_DB": "transition_records_db",
        "TRANSITION_RECORDS_COLLECTION": "transition_records_collection",
        "RULES_FILE_PATH": "rules_file_path",
        "START_TIME": "start_time",
        "END_TIME": "end_time",
        "DURATION": "duration",
        "END_TIME_CUTOFF": "end_time_cutoff",
        "CHANNEL": "channel",
        "GET_FIRST_CHAT": "get_first_chat",
        "CHAT_BOUNDARY_CHECK": "chat_boundary_check"
    }
    for key in configKeysMap:
        cmdValue = commandlineParams(param_key=configKeysMap[key], default=None, required=False)
        if cmdValue: configuration[key] = cmdValue



MONGO_URL = configuration.get("MONGO_URL", "mongodb://localhost:27017/?authSource=admin")
MONGO_TIMEOUT = configuration.get("MONGO_TIME_OUT", 30000)
LOG_FOLDER = valid_path(configuration.get("LOG_FOLDER","log/"))
LOG_NAME = configuration.get("LOG_NAME", "analyzer")
LOG_DEBUG_LEVEL = True if configuration.get("LOG_DEBUG", "true") == "true" else False
DATA_FOLDER = valid_path(configuration.get("DATA_FOLDER","data/"))
TRANSITION_RECORDS_DB = configuration.get("TRANSITION_RECORDS_DB", "koredbt001")
TRANSITION_RECORDS_COLLECTION = configuration.get("TRANSITION_RECORDS_COLLECTION", "transitionrecords")
RULES_FILE_PATH = configuration.get("RULES_FILE_PATH", "rules.json")
CONVERSATION_START_TIME = configuration.get("START_TIME", None)
CONVERSATION_END_TIME = configuration.get("END_TIME", None)
DURATION = str(configuration.get("DURATION", 60))
DURATION = int(DURATION) if DURATION.isnumeric() else 60
END_TIME_CUTOFF = str(configuration.get("DURATION", 10))
END_TIME_CUTOFF = int(END_TIME_CUTOFF) if END_TIME_CUTOFF.isnumeric() else 10
CHANNEL = configuration.get("CHANNEL", None)
GET_FIRST_CHAT = True if configuration.get("GET_FIRST_CHAT", "true") == "true" else False
CHAT_BOUNDARY_CHECK = True if configuration.get("CHAT_BOUNDARY_CHECK", "true") == "true" else False